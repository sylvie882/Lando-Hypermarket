// app/layout.tsx - ENHANCED SEO & PERFORMANCE
import type { Metadata, Viewport } from 'next';
import './globals.css';
import ClientLayout from './ClientLayout';
import { AuthProvider } from '@/lib/auth';
import { QueryProvider } from '@/lib/query';
import { Toaster } from 'react-hot-toast';
import AuthSync from '@/components/auth/AuthSync';
import Script from 'next/script';

const SITE_URL = 'https://hypermarket.co.ke';
const SITE_NAME = 'Lando Hypermarket';
const BUSINESS_PHONE = '+254 716 354 589';
const BUSINESS_EMAIL = 'landoranchh@gmail.com';
const BUSINESS_WHATSAPP = '+254716354589';
const BUSINESS_INSTAGRAM = 'landoranch_ke';
const BUSINESS_FACEBOOK = 'landoranch';

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#004E9A',
};

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: 'Lando Hypermarket | Fresh Vegetables, Pasture Raised Meat, Kienyeji Eggs, Baby Products & More',
    template: '%s | Lando Hypermarket'
  },
  description: 'Shop Lando Hypermarket for fresh farm produce: pasture raised meat (goat, sheep, rabbit), kienyeji eggs, fresh vegetables, tropical fruits, dairy products, baby essentials, stationery, cleaning supplies, wooden utensils, samosas, and traditional handicrafts. Everything you need and love. Amazing products, quickly delivered in 99 minutes at every day prices. Free delivery Nairobi. Order now!',
  keywords: [
    'fresh vegetables Nairobi', 'organic vegetables Kenya', 'traditional vegetables online',
    'leafy greens delivery', 'fresh vegetables delivery', 'farm fresh vegetables',
    'vegetable delivery Nairobi', 'green groceries online', 'sukuma wiki delivery',
    'managu online', 'terere vegetables', 'kunde leaves', 'cassava leaves', 'saget delivery',
    'pumpkin leaves', 'osuga vegetable', 'mrenda Kenya', 'spinach delivery', 'kale Nairobi',
    'cabbage online', 'root vegetables Nairobi', 'potatoes delivery', 'carrots online',
    'onions delivery', 'garlic Kenya', 'ginger online', 'arrow roots delivery',
    'sweet potatoes Nairobi', 'cassava fresh', 'yams Kenya', 'chopped vegetables delivery',
    'pre-cut vegetables Nairobi', 'prepared vegetables online', 'ready to cook vegetables',
    'mixed vegetables chopped', 'fresh fruits Nairobi', 'tropical fruits Kenya',
    'mangoes delivery', 'oranges online', 'bananas delivery', 'avocados Nairobi',
    'passion fruit Kenya', 'pineapple fresh', 'watermelon delivery', 'exotic fruits Kenya',
    'local fruits Nairobi', 'tree tomatoes', 'loquats', 'soursop', 'apple mangoes',
    'ngowe mangoes', 'kent mangoes', 'fresh mango delivery', 'pasture raised meat Kenya',
    'goat meat Nairobi', 'sheep meat delivery', 'rabbit meat Kenya', 'grass fed meat',
    'organic meat Nairobi', 'fresh goat meat', 'mutton delivery', 'rabbit meat online',
    'fresh meat delivery', 'animal products Kenya', 'farm fresh meat', 'quality meat Nairobi',
    'fresh chicken delivery', 'turkey meat Nairobi', 'duck meat Kenya', 'whole chicken',
    'chicken parts', 'poultry products', 'kienyeji eggs Nairobi', 'pasture raised eggs',
    'free range eggs Kenya', 'brown eggs delivery', 'farm fresh eggs', 'eggs kienyeji near me',
    'organic eggs Nairobi', 'traditional eggs', 'village eggs', 'fresh fish delivery Nairobi',
    'tilapia online', 'omena delivery', 'seafood Kenya', 'freshwater fish', 'fried fish',
    'fish fillets', 'fresh milk delivery', 'yogurt Nairobi', 'cheese Kenya', 'butter delivery',
    'fermented milk', 'mursik online', 'fresh cream', 'cow milk delivery', 'fresh cow milk',
    'goat milk Nairobi', 'camel milk Kenya', 'raw milk delivery', 'pasteurized milk',
    'premium milk', 'cereals Kenya', 'grains online', 'flour delivery Nairobi',
    'breakfast cereals', 'maize flour', 'wheat flour', 'rice delivery', 'cooking flour',
    'baking supplies', 'beans Kenya', 'lentils online', 'green grams', 'ndengu delivery',
    'peas Nairobi', 'legumes online', 'kidney beans', 'black beans', 'nuts Kenya',
    'seeds online', 'dried fruits Nairobi', 'groundnuts delivery', 'cashew nuts',
    'macadamia Kenya', 'pumpkin seeds', 'sunflower seeds', 'raisins online', 'dates delivery',
    'fresh herbs Nairobi', 'spices Kenya', 'coriander delivery', 'mint leaves',
    'rosemary fresh', 'thyme online', 'bay leaves', 'curry powder', 'turmeric fresh',
    'masala online', 'garam masala', 'spice mix Kenya', 'traditional spices',
    'mixed spices Nairobi', 'all purpose seasoning', 'blended spices', 'seasoning Kenya',
    'salt online', 'pepper delivery', 'seasoning mixes', 'baby products Kenya',
    'baby diapers delivery', 'baby formula Nairobi', 'baby food online', 'baby wipes Kenya',
    'baby care essentials', 'newborn items', 'baby lotion', 'baby shampoo', 'feeding bottles',
    'baby accessories', 'cleaning supplies Nairobi', 'professional cleaning products',
    'detergent delivery', 'cleaning equipment Kenya', 'hygiene products', 'disinfectants online',
    'floor cleaner', 'glass cleaner', 'cleaning tools', 'mops and brooms', 'cleaning chemicals',
    'commercial cleaning supplies', 'handicrafts Kenya', 'traditional crafts', 'kenyan artisans',
    'traditional utensils', 'african crafts', 'decorative items', 'cultural items',
    'handmade Kenya', 'local crafts', 'wooden utensils Kenya', 'wooden spoons',
    'cooking utensils wooden', 'eating utensils', 'serving ware Kenya', 'wooden bowls',
    'wooden plates', 'traditional wooden items', 'hand carved wood', 'sustainable kitchenware',
    'stationery Kenya', 'office supplies Nairobi', 'school supplies', 'pens online',
    'exercise books', 'printing paper', 'envelopes delivery', 'art supplies', 'craft materials',
    'notebooks', 'folders and files', 'beverages Kenya', 'juices delivery Nairobi',
    'soft drinks online', 'water delivery', 'energy drinks', 'fresh juice', 'traditional drinks',
    'healthy beverages', 'samosas Nairobi', 'fresh samosas delivery', 'beef samosas',
    'chicken samosas', 'vegetable samosas', 'kenyan snacks', 'pastries online',
    'ready to eat snacks', 'fresh flowers Nairobi', 'flower delivery Kenya',
    'decorative plants', 'bouquets online', 'indoor plants', 'garden plants',
    'supermarket in Nairobi', 'grocery delivery Westlands', 'shop online Kilimani',
    'groceries Lavington', 'delivery Kileleshwa', 'supermarket Karen', 'online shopping Langata',
    'grocery store Parklands', 'food delivery Nairobi CBD', 'groceries South B',
    'supermarket South C', 'delivery Buruburu', 'online grocery Donholm', 'shop Umoja',
    'delivery Eastlands', 'same day delivery Nairobi', 'express grocery delivery',
    'free delivery Nairobi', 'cash on delivery Kenya', 'M-Pesa payment online',
    'order groceries online', 'home delivery Kenya', '24 hour delivery Nairobi',
    'grocery app Kenya', 'online supermarket Kenya', 'grocery delivery Nairobi',
    'buy food online Kenya', 'shop for groceries', 'daily essentials', 'household items',
    'kitchen essentials', 'pantry staples', 'bulk groceries', 'mboga online', 'nyama delivery',
    'maharagwe online', 'unga delivery', 'mafuta ya kupikia', 'samli', 'bidii products',
    'kienyeji chicken', 'nyama ya mbuzi', 'nyama ya kondoo', 'samaki fresh', 'mayai kienyeji'
  ],
  authors: [{ name: 'Lando Hypermarket', url: 'https://hypermarket.co.ke/about' }],
  creator: 'Lando Hypermarket',
  publisher: 'Lando Hypermarket',
  formatDetection: { email: true, address: true, telephone: true },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_KE',
    url: SITE_URL,
    siteName: SITE_NAME,
    title: 'Lando Hypermarket | Fresh Vegetables, Pasture Raised Meat, Kienyeji Eggs & Baby Products',
    description: '🛒 Shop online: Fresh vegetables • Pasture raised meat (goat, sheep, rabbit) • Kienyeji eggs • Dairy • Baby products • Stationery • Cleaning supplies • Wooden utensils • Samosas • Handicrafts. Free delivery Nairobi over KES 2000!',
    images: [
      {
        url: `${SITE_URL}/og-image.jpg`,
        width: 1200,
        height: 630,
        alt: 'Lando Hypermarket - Online Supermarket for Fresh Produce, Meat, Eggs & Household Essentials',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    site: '@landohypermarket_ke',
    creator: '@landohypermarket_ke',
    title: 'Lando Hypermarket | Fresh Farm Produce & Groceries Delivered',
    description: 'Farm fresh vegetables, pasture raised meat, kienyeji eggs, baby products & more. Free delivery for all orders',
    images: [`${SITE_URL}/twitter-image.jpg`],
  },
  alternates: {
    canonical: SITE_URL,
    languages: {
      'en-KE': SITE_URL,
      'sw-KE': `${SITE_URL}/sw`,
    },
  },
  category: 'grocery',
  classification: 'Online Supermarket',
  verification: {
    google: '5696457e6978be87',
    other: { 'facebook-domain-verification': ['your-fb-verification-code'] },
  },
  other: {
    'geo.region': 'KE-30',
    'geo.placename': 'Nairobi',
    'geo.position': '-1.286389;36.817223',
    'ICBM': '-1.286389, 36.817223',
    'og:email': BUSINESS_EMAIL,
    'og:phone_number': BUSINESS_PHONE,
    'og:country-name': 'Kenya',
    'business:contact_data:street_address': 'Nairobi, Kenya',
    'business:contact_data:locality': 'Nairobi',
    'business:contact_data:country': 'KE',
    'category:vegetables': 'Fresh Vegetables, Leafy Greens, Root Vegetables, Pre-Cut Vegetables',
    'category:meat': 'Pasture Raised Meat (Goat, Sheep, Rabbit), Poultry',
    'category:eggs': 'Pasture Raised Eggs (Kienyeji), Free Range Eggs',
    'category:dairy': 'Cow Milk, Goat Milk, Camel Milk, Yogurt, Cheese',
    'category:produce': 'Fresh Fruits, Tropical Fruits, Mango Varieties',
    'category:grains': 'Cereals, Grains, Flours, Legumes, Beans',
    'category:spices': 'Herbs, Spices, Masala, Seasonings',
    'category:baby': 'Baby Products, Diapers, Formula, Baby Care',
    'category:cleaning': 'Cleaning Supplies, Equipment, Chemicals',
    'category:handicrafts': 'Wooden Utensils, Traditional Crafts, Serving Ware',
    'category:stationery': 'Office Supplies, School Supplies, Art Materials',
    'category:snacks': 'Samosas, Pastries, Ready to Eat',
    'category:beverages': 'Juices, Drinks, Water',
    'category:flowers': 'Fresh Flowers, Plants',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {

  // ─── JSON-LD objects ──────────────────────────────────────────────────────

  const jsonLdOrganization = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    '@id': `${SITE_URL}/#organization`,
    name: SITE_NAME,
    url: SITE_URL,
    logo: `${SITE_URL}/logo10.png`,
    image: `${SITE_URL}/og-image.jpg`,
    description: "Kenya's premier online supermarket offering fresh vegetables, pasture raised meat, kienyeji eggs, baby products, stationery, cleaning supplies, wooden utensils, samosas, handicrafts, and household essentials with express delivery in Nairobi.",
    address: {
      '@type': 'PostalAddress',
      addressLocality: 'Nairobi',
      addressRegion: 'Nairobi',
      addressCountry: 'KE',
    },
    contactPoint: [
      {
        '@type': 'ContactPoint',
        telephone: BUSINESS_PHONE,
        contactType: 'customer service',
        availableLanguage: ['English', 'Swahili'],
        hoursAvailable: {
          '@type': 'OpeningHoursSpecification',
          dayOfWeek: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
          opens: '08:00',
          closes: '20:00',
        },
      },
      { '@type': 'ContactPoint', telephone: BUSINESS_PHONE,    contactType: 'sales',     availableLanguage: ['English','Swahili'] },
      { '@type': 'ContactPoint', telephone: BUSINESS_WHATSAPP, contactType: 'whatsapp',  availableLanguage: ['English','Swahili'] },
    ],
    sameAs: [
      `https://www.facebook.com/${BUSINESS_FACEBOOK}`,
      `https://www.instagram.com/${BUSINESS_INSTAGRAM}`,
      `https://twitter.com/${BUSINESS_INSTAGRAM}`,
    ],
  };

  const jsonLdGroceryStore = {
    '@context': 'https://schema.org',
    '@type': 'GroceryStore',
    '@id': `${SITE_URL}/#store`,
    name: 'Lando Hypermarket',
    image: `${SITE_URL}/store-image.jpg`,
    url: SITE_URL,
    telephone: BUSINESS_PHONE,
    email: BUSINESS_EMAIL,
    priceRange: 'KES 20 - KES 5000',
    menu: `${SITE_URL}/products`,
    acceptsReservations: 'False',
    servesCuisine: 'Groceries, Fresh Produce, Meat, Dairy, Traditional Foods',
    areaServed: {
      '@type': 'GeoCircle',
      geoMidpoint: { '@type': 'GeoCoordinates', latitude: -1.286389, longitude: 36.817223 },
      geoRadius: '30000',
    },
    openingHoursSpecification: [
      { '@type': 'OpeningHoursSpecification', dayOfWeek: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'], opens: '08:00', closes: '20:00' },
      { '@type': 'OpeningHoursSpecification', dayOfWeek: 'Sunday', opens: '09:00', closes: '18:00' },
    ],
    hasOfferCatalog: {
      '@type': 'OfferCatalog',
      name: 'Product Categories',
      itemListElement: [
        { '@type': 'OfferCatalog', name: 'Fresh Vegetables',             url: `${SITE_URL}/categories/fresh-vegetables` },
        { '@type': 'OfferCatalog', name: 'Fresh Fruits',                 url: `${SITE_URL}/categories/fresh-fruits` },
        { '@type': 'OfferCatalog', name: 'Pasture Raised Meat',          url: `${SITE_URL}/categories/livestock-1` },
        { '@type': 'OfferCatalog', name: 'Kienyeji Eggs',                url: `${SITE_URL}/categories/egg` },
        { '@type': 'OfferCatalog', name: 'Dairy Products',               url: `${SITE_URL}/categories/dairy-products` },
        { '@type': 'OfferCatalog', name: 'Fish & Seafood',               url: `${SITE_URL}/categories/fish-seafood` },
        { '@type': 'OfferCatalog', name: 'Cereals & Organic Flour',      url: `${SITE_URL}/categories/grains-flours` },
        { '@type': 'OfferCatalog', name: 'Legumes & Beans',              url: `${SITE_URL}/categories/legumes-beans` },
        { '@type': 'OfferCatalog', name: 'Nuts, Seeds & Dried Fruits',   url: `${SITE_URL}/categories/nuts-seeds` },
        { '@type': 'OfferCatalog', name: 'Herbs, Spices & Seasonings',   url: `${SITE_URL}/categories/herbs-spices` },
        { '@type': 'OfferCatalog', name: 'Baby Products',                url: `${SITE_URL}/categories/baby-products` },
        { '@type': 'OfferCatalog', name: 'Cleaning Supplies',            url: `${SITE_URL}/categories/cleaning-materials-equipment` },
        { '@type': 'OfferCatalog', name: 'Handicrafts & Artisans',       url: `${SITE_URL}/categories/handicrafts-1` },
        { '@type': 'OfferCatalog', name: 'Wooden Utensils',              url: `${SITE_URL}/categories/wooden-utensils` },
        { '@type': 'OfferCatalog', name: 'Stationery',                   url: `${SITE_URL}/categories/stationery` },
        { '@type': 'OfferCatalog', name: 'Samosas & Snacks',             url: `${SITE_URL}/categories/samosas` },
        { '@type': 'OfferCatalog', name: 'Beverages',                    url: `${SITE_URL}/categories/beverages-1` },
        { '@type': 'OfferCatalog', name: 'Fresh Flowers & Plants',       url: `${SITE_URL}/categories/flowers-1` },
      ],
    },
  };

  const jsonLdWebsite = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    '@id': `${SITE_URL}/#website`,
    url: SITE_URL,
    name: SITE_NAME,
    description: 'Online supermarket in Nairobi offering fresh vegetables, pasture raised meat, kienyeji eggs, dairy, baby products, stationery, cleaning supplies, wooden utensils, samosas, handicrafts, and household essentials with express delivery.',
    publisher: { '@id': `${SITE_URL}/#organization` },
    potentialAction: {
      '@type': 'SearchAction',
      target: { '@type': 'EntryPoint', urlTemplate: `${SITE_URL}/search?q={search_term_string}` },
      'query-input': 'required name=search_term_string',
    },
  };

  const jsonLdLocalBusiness = {
    '@context': 'https://schema.org',
    '@type': 'LocalBusiness',
    '@id': `${SITE_URL}/#localbusiness`,
    name: 'Lando Hypermarket',
    image: `${SITE_URL}/store-front.jpg`,
    url: SITE_URL,
    telephone: BUSINESS_PHONE,
    priceRange: 'KES 20 - 5000',
    openingHours: 'Mo-Sa 08:00-20:00, Su 09:00-18:00',
    address: { '@type': 'PostalAddress', addressLocality: 'Nairobi', addressCountry: 'KE' },
    geo: { '@type': 'GeoCoordinates', latitude: -1.286389, longitude: 36.817223 },
    areaServed: 'Nairobi, Kenya',
    makesOffer: [
      { '@type': 'Offer', itemOffered: { '@type': 'Service',  name: 'Grocery Delivery',    description: 'Express grocery delivery in 45-99 minutes' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Product',  name: 'Fresh Vegetables',    description: 'Locally sourced fresh vegetables including leafy greens and root vegetables' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Product',  name: 'Pasture Raised Meat', description: 'Goat, sheep, and rabbit meat from grass-fed animals' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Product',  name: 'Kienyeji Eggs',       description: 'Fresh pasture raised eggs from free-range chickens' } },
      { '@type': 'Offer', itemOffered: { '@type': 'Product',  name: 'Fresh Fruits',        description: 'Farm fresh fruits including mango varieties and tropical fruits' } },
    ],
  };

  // FIX: All slugs now match your real API (/categories/ not /category/)
  const jsonLdBreadcrumb = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1,  name: 'Home',                   item: SITE_URL },
      { '@type': 'ListItem', position: 2,  name: 'Fresh Vegetables',        item: `${SITE_URL}/categories/fresh-vegetables` },
      { '@type': 'ListItem', position: 3,  name: 'Pasture Raised Meat',     item: `${SITE_URL}/categories/livestock-1` },
      { '@type': 'ListItem', position: 4,  name: 'Kienyeji Eggs',           item: `${SITE_URL}/categories/egg` },
      { '@type': 'ListItem', position: 5,  name: 'Fresh Fruits',            item: `${SITE_URL}/categories/fresh-fruits` },
      { '@type': 'ListItem', position: 6,  name: 'Dairy Products',          item: `${SITE_URL}/categories/dairy-products` },
      { '@type': 'ListItem', position: 7,  name: 'Baby Products',           item: `${SITE_URL}/categories/baby-products` },
      { '@type': 'ListItem', position: 8,  name: 'Cleaning Supplies',       item: `${SITE_URL}/categories/cleaning-materials-equipment` },
      { '@type': 'ListItem', position: 9,  name: 'Handicrafts & Artisans',  item: `${SITE_URL}/categories/handicrafts-1` },
      { '@type': 'ListItem', position: 10, name: 'Wooden Utensils',         item: `${SITE_URL}/categories/wooden-utensils` },
      { '@type': 'ListItem', position: 11, name: 'Stationery',              item: `${SITE_URL}/categories/stationery` },
      { '@type': 'ListItem', position: 12, name: 'Samosas',                 item: `${SITE_URL}/categories/samosas` },
      { '@type': 'ListItem', position: 13, name: 'Spices & Herbs',          item: `${SITE_URL}/categories/herbs-spices` },
      { '@type': 'ListItem', position: 14, name: 'Cereals & Organic Flour', item: `${SITE_URL}/categories/grains-flours` },
      { '@type': 'ListItem', position: 15, name: 'Fresh Flowers & Plants',  item: `${SITE_URL}/categories/flowers-1` },
    ],
  };

  return (
    <html lang="en-KE">
      <head>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />

        <meta name="google-site-verification" content="5696457e6978be87" />

        <meta name="description" content="✓ Fresh Vegetables • Pasture Raised Meat (Goat, Sheep, Rabbit) • Kienyeji Eggs • Fresh Fruits • Dairy • Baby Products • Stationery • Cleaning Supplies • Wooden Utensils • Samosas • Handicrafts. Free delivery Nairobi over KES 2000. Order online now!" />

        <link rel="canonical" href={SITE_URL} />
        <link rel="alternate" href={SITE_URL} hrefLang="en-KE" />
        <link rel="alternate" href={`${SITE_URL}/sw`} hrefLang="sw-KE" />
        <link rel="alternate" href={SITE_URL} hrefLang="x-default" />

        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,500;0,9..144,700;0,9..144,900;1,9..144,400;1,9..144,700&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
        <link rel="preconnect" href="https://api.hypermarket.co.ke" />
        <link rel="dns-prefetch" href="https://www.google-analytics.com" />

        <link rel="icon" type="image/x-icon" href="/favicon.ico" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/site.webmanifest" />
        <meta name="msapplication-TileColor" content="#004E9A" />
        <meta name="theme-color" content="#004E9A" />

        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Hypermarket" />
        <meta name="format-detection" content="telephone=yes" />
        <meta name="mobile-web-app-capable" content="yes" />

        <meta name="service-type" content="Grocery Delivery" />
        <meta name="delivery-areas" content="Nairobi, Kiambu, Westlands, Kilimani, Lavington, Kileleshwa, Karen, Langata, Parklands, South B, South C, Buruburu, Donholm, Umoja, Eastlands" />
        <meta name="payment-methods" content="M-Pesa, Cash on Delivery, Credit Card, Debit Card" />
        <meta name="delivery-time" content="45-99 minutes" />
        <meta name="free-delivery-threshold" content="KES 2000" />
        <meta name="products" content="Fresh Vegetables, Leafy Greens, Root Vegetables, Pre-Cut Vegetables, Fresh Fruits, Tropical Fruits, Mangoes, Pasture Raised Meat (Goat, Sheep, Rabbit), Poultry, Kienyeji Eggs, Fresh Fish, Dairy Products, Cow Milk, Goat Milk, Camel Milk, Cereals, Grains, Flours, Legumes, Beans, Nuts, Seeds, Herbs, Spices, Masala, Baby Products, Diapers, Cleaning Supplies, Equipment, Handicrafts, Wooden Utensils, Stationery, Samosas, Beverages, Fresh Flowers" />

        {/*
          FIX 1: Schema is now inline — NOT strategy="afterInteractive".
          Googlebot crawls raw HTML before JS executes. With afterInteractive
          these scripts were injected after hydration, meaning Googlebot never
          saw them. Inline <script> tags are in the initial HTML response.
        */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdOrganization) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdGroceryStore) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdWebsite) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdLocalBusiness) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdBreadcrumb) }}
        />
      </head>
      <body className="font-sans antialiased">
        <QueryProvider>
          <AuthProvider>
            <ClientLayout>
              {children}
            </ClientLayout>
            <AuthSync />
            <Toaster
              position="top-right"
              toastOptions={{
                duration: 4000,
                style: { background: '#363636', color: '#fff' },
                success: { duration: 3000, style: { background: '#004E9A' } },
              }}
            />
          </AuthProvider>
        </QueryProvider>

        {/* Google Analytics 4 — replace G-XXXXXXXXXX with your real GA4 ID */}
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-XXXXXXXXXX', {
              send_page_view: true,
              transport_type: 'beacon',
              anonymize_ip: true
            });
          `}
        </Script>

        {/* Facebook Pixel — replace YOUR_PIXEL_ID with your real pixel ID */}
        <Script id="facebook-pixel" strategy="afterInteractive">
          {`
            !function(f,b,e,v,n,t,s)
            {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
            n.callMethod.apply(n,arguments):n.queue.push(arguments)};
            if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
            n.queue=[];t=b.createElement(e);t.async=!0;
            t.src=v;s=b.getElementsByTagName(e)[0];
            s.parentNode.insertBefore(t,s)}(window, document,'script',
            'https://connect.facebook.net/en_US/fbevents.js');
            fbq('init', 'YOUR_PIXEL_ID');
            fbq('track', 'PageView');
          `}
        </Script>

        <Script id="structured-data-products" strategy="afterInteractive">
          {`window.productData = window.productData || [];`}
        </Script>
      </body>
    </html>
  );
}